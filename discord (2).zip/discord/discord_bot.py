import discord
from discord.ext.commands import Bot
from discord.ext import commands
import asyncio
import time


Client = discord.Client() #Initialise Client 
client = commands.Bot(command_prefix = "?") #Initialise client bot

chat_filter = ["NIGGER", "FAGGOT", "NIGR", "KILLYOURSELF FAGOT", "Daddy" ]

@client.event 
async def on_ready():
    print("Bot is online and connected to Discord") #This will be called when the bot connects to the server

@client.event
async def on_message(message):
    if message.content == "#TakeMeToClassRoom":
        await client.send_message(message.channel, "https://classroom.google.com/u/0/h")




@client.event
async def on_message(message):
    if message.content.upper().startswith('!DAD'):
        userID = message.author.id
        await client.send_message(message.channel, "<@%s> Yes Organism?" % (userID))
    if message.content.upper().startswith('?SEKOLBOT'):
        if message.author.id == "<user id>": #Replace <User ID> with the ID of the user you want to be able to execute this command!
            args = message.content.split(" ")
            await client.send_message(message.channel, "%s" % (" ".join(args[1:])))
        else:
            await client.send_message(message.channel, "Whats Up")
    if message.content.upper().startswith('!AMIADMIN'):
        if "514626902351151115" in [role.id for role in message.author.roles]: #Replace <Role ID> with the ID of the role you want to be able to execute this command
            await client.send_message(message.channel, "You are an admin")
        else:
            await client.send_message(message.channel, "You are not an admin")


        
@client.event
async def on_message(message):
    contents = message.content.split(" ")
    for word in contents:
        if word.upper() in chat_filter:
            await client.delete_message(message)
            await client.send_message (message.channel, "**Hey!! Watch Your Profanity**")

    
client.run("NTE0NTEzNTk2NjMwNDMzODMw.DtZJOA.J_1NafDPzDCYmZ76GbiTcmUzv5g") #Replace token with your bots token
